import json
import random
import typing as t
import uuid
import user_agents as ua
from requests import Session, Response
from requests.cookies import RequestsCookieJar, create_cookie
from http.cookies import SimpleCookie
from fake_useragent import UserAgent
from .__util__ import *


class XGlobal:
    originUrl: str = "https://www.xiaohongshu.com"
    baseUrl: str = "https://edith.xiaohongshu.com"
    xhsVersion1: str = "4.1.0"
    webBuildVersion: str = "4.62.2"
    xhsAppId: str = "xhs-pc-web"
    b1Version: str = "3.3.3"
    b1b1: str = Default.RC4_VERSION


class XObject:
    class XConfig:
        def __init__(self, xo: "XObject"):
            self.xo: "XObject" = xo
            self.createTime: int = getNowMsTime()
            self.autoSetCookie: bool = True
            self.networkProxies: t.Dict = Default.PROXIES
            self.autoChangeB1Rule: t.Callable[[int], bool] = self.defaultChangeB1Rule
            self.fetchCount: int = 1
            self.hasPlugin: bool = False
            self.supportWebGL: bool = True
            self.isWebdriver: bool = False
            self.supportMediaQuery: bool = True
            self.isHeadless: bool = False
            self.environment = "0|0|0|1|0|0|1|0|0|0|1|0|0|0|0|1|0|0|0"
            self.browsers: t.List[t.Literal["chrome", "edge", "firefox", "safari"]] = [
                "chrome"
            ]
            self.systems: t.List[t.Literal["windows", "macos", "linux"]] = [
                "windows",
                "macos",
                "linux",
            ]
            self.customB1: str = ""
            self._useragent: str = ""
            self._cookieJar: RequestsCookieJar = RequestsCookieJar()
            self._headers = {}

        def defaultChangeB1Rule(self, fetchCount: int) -> bool:
            return bool(self.fetchCount - fetchCount) and False

        def checkChangeB1Rule(self):
            if not self.autoChangeB1Rule(self.fetchCount):
                return
            self.fetchCount = 1
            self.hasPlugin = random.choice([True, False])
            self.createTime = getNowMsTime()
            self.useragent = ''
            self.supportWebGL = random.choice([True, False])
            self.supportMediaQuery = random.choice([True, False])
            self._cookieJar.pop("a1")
            self._cookieJar.pop("webId", "")
            self.cookie = "; ".join([f"{k}={v}" for k, v in self.cookie.items()])

        def parseCookie(self, simpleCookie: SimpleCookie):
            cookieJar = RequestsCookieJar()
            for key, morsel in simpleCookie.items():
                if key == "web_session":
                    cookieJar.set_cookie(
                        create_cookie(
                            morsel.key,
                            morsel.value,
                            domain=".xiaohongshu.com",
                            secure=True,
                            rest={"HttpOnly": None},
                        )
                    )
                elif key == "acw_tc":
                    cookieJar.set_cookie(
                        create_cookie(
                            morsel.key,
                            morsel.value,
                            domain="edith.xiaohongshu.com",
                            rest={"HttpOnly": True},
                        )
                    )
                else:
                    cookieJar.set_cookie(
                        create_cookie(
                            morsel.key,
                            morsel.value,
                            domain=".xiaohongshu.com",
                        )
                    )

            if not cookieJar.get("a1"):
                cookieJar.set_cookie(
                    create_cookie(
                        "a1",
                        self.xo.core.generateLocalA1(),
                    )
                )

            if not cookieJar.get("webId"):
                cookieJar.set_cookie(
                    create_cookie(
                        "webId",
                        getDataMD5(cookieJar["a1"]),
                    )
                )

            if not cookieJar.get("webBuild"):
                cookieJar.set_cookie(
                    create_cookie(
                        "webBuild",
                        XGlobal.webBuildVersion,
                    )
                )

            if not cookieJar.get("xsecappid"):
                cookieJar.set_cookie(
                    create_cookie(
                        "xsecappid",
                        XGlobal.xhsAppId,
                    )
                )

            return cookieJar

        @property
        def useragent(self):
            return ua.parse(self._useragent)

        @useragent.setter
        def useragent(self, uaString: str):
            parsedUa = ua.parse(uaString)
            if str(parsedUa) == "Other / Other / Other":
                uaString = UserAgent(
                    browsers=self.browsers, os=self.systems, platforms="pc"
                ).random

            self._useragent = uaString

        @property
        def platform(self) -> str:
            return self.useragent.os.family

        @property
        def platformCode(self) -> int:
            return getPlatformCode(self.platform)

        @property
        def cookie(self):
            return self._cookieJar

        @cookie.setter
        def cookie(self, cookie):
            self._cookieJar = self.parseCookie(SimpleCookie(cookie))

        @property
        def a1(self):
            return self.cookie.get("a1", "")

        @property
        def webId(self):
            return self.cookie.get("webId", "")

        @property
        def webSession(self):
            return self.cookie.get("web_session", "")

        @property
        def webBuild(self):
            return self.cookie.get("webBuild", "")

        @property
        def xsecappid(self):
            return self.cookie.get("xsecappid", "")

        @property
        def browserCoreId(self):
            browserName = self.useragent.browser.family
            return Default.BROWSER_CORE_IDS.get(
                browserName, Default.BROWSER_CORE_IDS["Other"]
            )

        @property
        def b1(self):
            if self.customB1:
                return self.customB1

            x37 = [0, 0, 0, 0, 0] + [0, 0, 0, 0]
            x37 += [1] if self.hasPlugin else [0]
            x37 += [0] if self.supportWebGL else [1]
            x37 += [0] + [0, 0, 0]
            x37 += [1, 0, 1] if self.isWebdriver else [0, 0, 0]
            x37 += [1, 0] if self.supportMediaQuery else [0, 0]
            x37 += [0]
            x37 += [1] if self.isWebdriver else [0]
            x37 += [1] if self.isHeadless else [0]
            x37 += [0]

            x37 = "|".join(str(i) for i in x37)

            x46 = "true" if self.isWebdriver else "false"

            info = {
                "x33": "0",
                "x34": "0",
                "x35": "0",
                "x36": "2",
                "x37": x37,
                "x38": "0|0|1|0|1|0|0|0|0|0|1|0|1|0|1|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0|0",
                "x39": str(self.fetchCount),
                "x42": XGlobal.b1Version,
                "x43": self.browserCoreId,
                "x44": str(self.createTime),
                "x45": "connecterror",
                "x46": x46,
                "x48": "",
                "x49": "{list:[],type:}",
                "x50": "",
                "x51": "",
                "x52": "[]",
            }

            return self.xo.core.getXMiniUA(info)

        @property
        def searchId(self):
            return f"2c{str(uuid.uuid4()).replace('-', '')[:21 - 2]}"

        @property
        def requestId(self):
            return f"{uuid.uuid4().hex[:9]}-{getNowMsTime()}"

        def setHeaders(self, headers: t.Dict):
            self._headers = headers

        def addHeaders(self, headers: t.Dict):
            self._headers.update(headers)

        def getHeaders(self, headers: t.Optional[t.Dict] = None):
            baseHeaders = self.headers
            baseHeaders.update(headers or {})
            return baseHeaders

        @property
        def headers(self):
            headers = {
                "accept": "application/json, text/plain, */*",
                "accept-encoding": "gzip, deflate, br, zstd",
                "accept-language": "zh-CN,zh;q=0.9",
                "content-type": "application/json;charset=UTF-8",
                "host": "edith.xiaohongshu.com",
                "origin": XGlobal.originUrl,
                "referer": XGlobal.originUrl + '/',
                "sec-fetch-dest": "empty",
                "sec-fetch-mode": "cors",
                "sec-fetch-site": "same-site",
                "sec-gpc": "1",
                "dnt": "1",
                "x-mns": "unload",
                "user-agent": self.useragent.ua_string,
            }
            headers.update(self._headers)
            return headers

    class XCore:
        def __init__(self, xo: "XObject") -> None:
            self.xo: "XObject" = xo
            self.createTime: int = getNowMsTime()

        def getXSignAndXTime(
            self, api: str, data: t.Optional[t.Dict], time: t.Union[int, str]
        ):
            x1 = f"x1={getDataMD5(concatAPIAndData(api, data))}"
            x2 = f"x2={self.xo.config.environment}"
            x3 = f"x3={self.xo.config.a1}"
            x4 = f"x4={time}"
            x5 = ""
            plaintext = ";".join((x1, x2, x3, x4, x5))
            payload = encryptAES(
                plaintext, Default.ST_KEY, Default.ST_IV, Default.ST_TAIL
            )
            signObj = {
                "signSvn": Default.ST_SVN_VERSION,
                "signType": Default.ST_TYPE,
                "appId": XGlobal.xhsAppId,
                "signVersion": Default.RC4_VERSION,
                "payload": payload,
            }
            signText = json.dumps(signObj, separators=(",", ":"), ensure_ascii=False)
            return f"XYW_{encodeBase64(signText)}", str(time)

        def getXSignCommon(self, xSign: str, xTime: t.Union[int, str]):
            b1 = self.xo.config.b1
            commonInfo = {
                "s0": self.xo.config.platformCode,  # 系统编码
                "s1": "",  # 固定空值
                "x0": XGlobal.b1b1,
                "x1": XGlobal.xhsVersion1,  # 版本号1
                "x2": self.xo.config.platform or "PC",  # 系统
                "x3": XGlobal.xhsAppId,  # 红书ID
                "x4": XGlobal.webBuildVersion,  # webBuild 版本
                "x5": self.xo.config.a1,  # a1
                "x6": int(xTime),  # x-t
                "x7": xSign,  # x-s
                "x8": b1,  # 浏览器指纹
                "x9": getDataXHSCRC32(f"{xTime}{xSign}{b1}"),
                "x10": self.xo.config.fetchCount,
            }
            commonText = json.dumps(
                commonInfo, separators=(",", ":"), ensure_ascii=False
            )
            return encodeCustomBase64(commonText.encode())

        def getXMiniUA(self, info: t.Dict):
            infoText = json.dumps(info, separators=(",", ":"), ensure_ascii=False)
            rc4Text = encryptRC4(infoText, Default.RC4_KEY)
            browserB1 = encodeCustomBase64(rc4Text.encode())
            return browserB1

        def getXb3TraiceId(self):
            return "".join(random.choices("abcdef0123456789", k=16))

        def generateLocalA1(self):
            dataArray = [
                hex(getNowMsTime())[2:],
                generateRandomString(30),
                str(self.xo.config.platformCode),
                "0",
                "000",
            ]
            crc32 = getDataISOCRC32("".join(dataArray))
            dataArray.append(str(crc32))
            return "".join(dataArray)[0:52]

        def genderateXrayId(self):
            return generateTraceId()

    def __init__(
        self,
        *,
        useragent: t.Union[str, None] = None,
        cookie: t.Union[str, t.Dict, None] = None,
    ):
        self.createTime = getNowMsTime()

        self.config = self.XConfig(self)
        self.core = self.XCore(self)
        self.events = XEvents(self)

        self.config.useragent = useragent or ""
        self.config.cookie = cookie or ""

    @property
    def id(self):
        return f"{hash(self)}-{self.createTime}"

    def fetch(
        self,
        method: t.Literal["GET", "POST", "OPTIONS"],
        api: str,
        data: t.Optional[dict] = None,
        headers: t.Optional[t.Dict[str, str]] = None,
    ) -> "XResult":
        realMethod = method.upper()
        argHeaders = headers or {}
        xResult = XResult(
            None, api=api, method=realMethod, payload=data, headers=argHeaders
        )

        try:
            self.events.emit("ready-fetch", realMethod, api, data, argHeaders)

            nowTime = getNowMsTime()

            if realMethod == "GET":
                api = getUrlWithParams(api, data)
                payload = None
                xSign, xTime = self.core.getXSignAndXTime(api, None, nowTime)
                xSignCommon = self.core.getXSignCommon(xSign, xTime)
                traceId = self.core.genderateXrayId()
                realHeaders = self.config.getHeaders(
                    {
                        "x-b3-traceid": self.core.getXb3TraiceId(),
                        "x-s": xSign,
                        "x-s-common": xSignCommon,
                        "x-t": xTime,
                        "x-xray-traceid": traceId,
                    }
                )
            elif realMethod == "POST":
                payload = json.dumps(
                    data, ensure_ascii=False, separators=(",", ":")
                ).encode()
                xSign, xTime = self.core.getXSignAndXTime(api, data, nowTime)
                xSignCommon = self.core.getXSignCommon(xSign, xTime)
                traceId = self.core.genderateXrayId()
                realHeaders = self.config.getHeaders(
                    {
                        "x-b3-traceid": self.core.getXb3TraiceId(),
                        "x-s": xSign,
                        "x-s-common": xSignCommon,
                        "x-t": xTime,
                        "x-xray-traceid": traceId,
                    }
                )
            elif realMethod == "OPTIONS":
                payload = None
                realHeaders = self.config.getHeaders(argHeaders)
            else:
                raise ValueError(f"Fetch method {realMethod} is not supported.")

            realHeaders.update(argHeaders)

            self.events.emit("fetch-before", realMethod, api, payload, realHeaders)

            with Session() as session:
                response = session.request(
                    method=realMethod,
                    url=joinBaseUrlAPI(XGlobal.baseUrl, api),
                    data=payload,
                    headers=realHeaders,
                    proxies=self.config.networkProxies,
                    cookies=self.config.cookie,
                )

            xResult = XResult(
                response, api=api, method=realMethod, payload=data, headers=realHeaders
            )
            self.events.emit("fetch-success", xResult)
        except Exception as e:
            self.events.emit("fetch-failure", e)
            xResult = XResult(
                None,
                msg=str(e),
                api=api,
                method=realMethod,
                payload=data,
                headers=argHeaders,
            )
        finally:
            self.config.fetchCount += 1
            self.events.emit("fetch-finished", xResult)
            return xResult

    def get(
        self,
        api: str,
        data: t.Optional[dict] = None,
        headers: t.Optional[dict] = None,
    ):
        return self.fetch("GET", api, data, headers)

    def post(
        self,
        api: str,
        data: t.Optional[dict] = None,
        headers: t.Optional[dict] = None,
    ):
        return self.fetch("POST", api, data, headers)

    def options(
        self,
        api: str,
        realMethod: str = "GET",
        headers: t.Optional[dict] = None,
    ):
        headers = headers or {}
        customHeaders = {
            "accept": "*/*",
            "access-control-request-headers": "content-type,sc-t,x-b3-traceid,x-mns,x-s,x-s-common,x-t,x-xray-traceid",
            "access-control-request-method": realMethod.upper(),
            "cookie": "",
        }
        customHeaders.update(headers)
        return self.fetch("OPTIONS", api, headers=customHeaders)

    def updateFecthCount(self, count: int):
        self.config.fetchCount = count

    def resetFetchCount(self):
        self.config.fetchCount = 1

    def generateUserAgent(
        self,
        browser: t.Literal["chrome", "edge", "firefox", "safari"] = "chrome",
        system: t.Literal["windows", "macos", "linux"] = "windows",
    ) -> str:
        if system in ["android", "ios"]:
            system = "windows"

        self.config.useragent = UserAgent(
            browsers=browser, os=system, platforms="pc"
        ).random
        return self.config.useragent.ua_string

    def __str__(self):
        return f"XObject(id='{self.id}')"

    def __repr__(self):
        return f"XObject(id='{self.id}')"


class XResult:
    def __init__(
        self,
        response: t.Optional[Response],
        *,
        msg: str = "",
        api: str = "",
        method: str = "",
        payload: t.Optional[t.Dict] = None,
        headers: t.Dict[str, str] = {},
    ) -> None:
        self.createTime = getNowMsTime()
        self._response = response
        self.msg: str = msg  # 可能没有
        self.data: t.Dict = {}  # 可能没有
        self.success: bool = False  # 必有
        self.code: int = -1  # 必有
        self.api: str = api
        self.method: str = method
        self.payload: t.Optional[t.Dict] = payload
        self._requestHeaders = headers
        self._parseResponse()

    def _parseResponse(self):
        if self.method == "OPTIONS":
            self.success = True
            self.code = 0
            return

        if self._response is None:
            return

        raw = {
            "success": self.success,
            "msg": self.msg,
            "data": self.data,
            "code": self.code,
        }

        try:
            raw = self._response.json()
        except ValueError:
            raw["msg"] = self._response.text

        self.msg = raw.get("msg", self.msg)
        self.data = raw.get("data", self.data)
        self.success = raw.get("success", self.success)
        self.code = raw.get("code", self.code)

    @property
    def response(self):
        return self._response

    @property
    def respCode(self):
        if self._response is None:
            return 0

        return self._response.status_code

    @property
    def respHeaders(self) -> t.Dict[str, str]:
        if self._response is None:
            return {}

        return dict(self._response.headers)

    @property
    def reqHeaders(self) -> t.Dict[str, str]:
        return self._requestHeaders

    @property
    def respCookieJar(self):
        if self._response is None:
            return None
        return self._response.cookies

    def info(self):
        print(json.dumps(self.data, ensure_ascii=False, separators=(",", ":")))
        return self

    def debug(
        self,
        showData: bool = True,
        showReqHeaders: bool = False,
        showRespHeaders: bool = False,
    ):
        creatTime = convertTimestamp(self.createTime)
        prefix = f"* XResult<{creatTime}> "
        infos = [
            str(self.success),
            str(self.code),
            str(self.respCode),
            self.msg,
            self.api,
            self.method,
        ]
        print(prefix + " | ".join(infos))
        if showData:
            print(
                "- Data:",
                json.dumps(self.data, ensure_ascii=False, separators=(",", ":")),
            )

        if showReqHeaders:
            print(
                "- Request Headers:",
                json.dumps(self.reqHeaders, ensure_ascii=False, separators=(",", ":")),
            )

        if showRespHeaders:
            print(
                "- Response Headers:",
                json.dumps(self.respHeaders, ensure_ascii=False, separators=(",", ":")),
            )
        return self

    def toObject(self):
        jsonData = {
            "success": self.success,
            "msg": self.msg,
            "data": self.data,
            "code": self.code,
        }
        return jsonData

    def toJson(
        self,
        *,
        skipkeys: bool = False,
        ensureAscii: bool = False,
        checkCircular: bool = True,
        allowNan: bool = True,
        cls: t.Optional[t.Type[json.JSONEncoder]] = None,
        indent: t.Union[int, str, None] = None,
        separators: t.Optional[t.Tuple[str, str]] = (",", ":"),
        default: t.Optional[t.Callable[[t.Any], t.Any]] = None,
        sortKeys: bool = False,
    ):
        return json.dumps(
            self.toObject(),
            skipkeys=skipkeys,
            ensure_ascii=ensureAscii,
            check_circular=checkCircular,
            allow_nan=allowNan,
            cls=cls,
            indent=indent,
            separators=separators,
            default=default,
            sort_keys=sortKeys,
        )

    def __repr__(self):
        string = ", ".join(
            [
                f"{k}={type(v)}" if k == "data" else f"{k}='{v}'"
                for k, v in self.toObject().items()
            ]
        )
        return f"XResult({string})"


class XEvent:
    def __init__(self, eventName: str, callback: t.Callable):
        self.createTime = getNowMsTime()
        self._eventName = eventName
        self._callback = callback

    def __call__(self, *args):
        try:
            result = self._callback(*args)
            return result
        except Exception as e:
            print(f"Execute event `{self._eventName}` occur error:", e)

    @property
    def id(self):
        return f"{hash(self)}-{self.createTime}"

    def __repr__(self):
        return f"XEvent(id={self.id!r}, event={self._eventName!r})"


class XEvents:
    def __init__(self, xo: XObject):
        self.xo = xo
        self.createTime = getNowMsTime()
        self._events: t.Dict[str, t.List[XEvent]] = {
            "ready-fetch": [],
            "fetch-before": [],
            "fetch-success": [],
            "fetch-failure": [],
            "fetch-finished": [],
        }
        self._eventIdToNames: t.Dict[str, str] = {}

    def on(
        self,
        eventName: str,
        callback: t.Union[
            t.Callable[[XObject, str, str, t.Optional[t.Dict], t.Dict], t.Any],
            t.Callable[[XObject, str, str, t.Optional[bytes], t.Dict], t.Any],
            t.Callable[[XObject, Exception], t.Any],
            t.Callable[[XObject, XResult], t.Any],
        ],
    ) -> str:
        if eventName not in self._events:
            raise ValueError(f"Event {eventName} is not supported.")

        xEvent = XEvent(eventName, callback)
        self._events[eventName].append(xEvent)
        self._eventIdToNames[xEvent.id] = eventName
        return xEvent.id

    def off(self, eventIdOrName: str):
        if eventIdOrName in self._events:
            for xEvent in self._events[eventIdOrName]:
                self._eventIdToNames.pop(xEvent.id, None)
            self._events[eventIdOrName] = []
            return

        eventName = self._eventIdToNames.get(eventIdOrName)
        if eventName is None:
            return

        self._eventIdToNames.pop(eventIdOrName, None)

        events = self._events.get(eventName)
        if events is None:
            return

        for event in reversed(events):
            if event.id == eventIdOrName:
                events.remove(event)
                break

    def getEvents(self, eventName: str = ""):
        return self._events.get(eventName, [])

    @property
    def allEvents(self):
        return self._events

    def emit(self, eventName: str, *args, **kwargs):
        self._executeDefaultEvents(eventName, *args, **kwargs)
        events = self.getEvents(eventName)
        for event in events:
            event(self.xo, *args, **kwargs)

    def _executeDefaultEvents(self, eventName: str, *args, **kwargs):
        if eventName == "fetch-success":
            self.setCookie(self.xo, args[0])
        elif eventName == "fetch-finished":
            self.xo.config.checkChangeB1Rule()

    def setCookie(self, xo: XObject, xr: XResult):
        if not xo.config.autoSetCookie:
            return
        cookieJar = xr.respCookieJar
        if not cookieJar:
            return
        xo.config.cookie.update(cookieJar)

    def __repr__(self):
        return f"XEvents(count={len(self._eventIdToNames)!r})"
