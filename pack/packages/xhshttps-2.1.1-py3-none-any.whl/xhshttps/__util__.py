import time
import base64
import hashlib
import json
import random
import typing as t
from datetime import datetime
from http.cookiejar import CookieJar
from urllib.parse import urlencode, urlparse, urlunparse
from Crypto.Cipher import AES, ARC4


class Default:
    # 网络代理
    PROXIES = {"http": None, "https": None}
    # 已知内核ID
    BROWSER_CORE_IDS = {
        "Chrome": "022cbd2c",
        "Edge": "022cbd2c",
        "Firefox": "9b2ced2c",
        "Other": "022cbd2c",
    }
    # X-s 和 X-t
    ST_KEY = [929260340, 1633971297, 895580464, 925905270]
    ST_IV = [52, 117, 122, 106, 114, 55, 109, 98, 115, 105, 98, 99, 97, 108, 100, 112]
    ST_TAIL = 8
    ST_SVN_VERSION = "56"
    ST_TYPE = "x2"
    # ST_VERSION = '1'
    # 自定义 base64 编码
    CUSTOM_BASE64_LOOKUP = (
        b"ZmserbBoHQtNP+wOcza/LpngG8yJq42KWYj0DSfdikx3VT16IlUAFM97hECvuRX5"
    )
    STANDARD_BASE64_LOOKUP = (
        b"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    )
    # RC4 b1 b1b1
    RC4_KEY = "xhswebmplfbt"
    RC4_VERSION = "1"


class Int:
    MAX_SEQ = 8388607  # 2^23 - 1
    SEQ = random.getrandbits(23)  # 初始随机序列号

    @staticmethod
    def random(exponent):
        return random.getrandbits(exponent)

    @staticmethod
    def seq():
        if Int.SEQ >= Int.MAX_SEQ:
            Int.SEQ = 0
        rawSeq = Int.SEQ
        Int.SEQ += 1
        return rawSeq


def getNowMsTime():
    return int(time.time() * 1000)


def convertTimestamp(timestamp: int):
    realTimestamp = int(timestamp / 1000)
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(realTimestamp))


def getPlatformCode(platform: str):
    platformCodes = {
        "iOS": 1,
        "Android": 2,
        "Mac OS X": 3,
        "Linux": 4,
        "other": 5,
    }
    return platformCodes.get(platform, platformCodes["other"])


def unsignedRightShift(n, i):
    """模拟 JavaScript 的无符号右移 (>>>)"""
    return (n % 0x100000000) >> i


def convert2StringCookie(cookie):
    if not cookie:
        return ""

    if isinstance(cookie, str):
        return cookie
    elif isinstance(cookie, dict):
        return "; ".join(f"{k}={v}" for k, v in cookie.items())
    elif isinstance(cookie, list):
        if all(isinstance(ck, dict) for ck in cookie):
            return "; ".join(f'{ck["name"]}={ck["value"]}' for ck in cookie)
        else:
            return "; ".join(cookie)
    elif isinstance(cookie, CookieJar):
        return "; ".join(f"{ck.name}={ck.value}" for ck in cookie)

    try:
        # 尝试解析为 JSON
        cookie_dict = json.loads(cookie)
        return "; ".join(f"{k}={v}" for k, v in cookie_dict.items())
    except json.JSONDecodeError:
        try:
            # 尝试解析为 URL 编码的字符串
            cookie_dict = dict(pair.split("=") for pair in cookie.split("&"))
            return "; ".join(f"{k}={v}" for k, v in cookie_dict.items())
        except ValueError:
            raise ValueError("Unsupported cookie format")


def getUrlWithParams(url: str, params: t.Optional[dict] = None) -> str:
    if not params:
        return url

    parsedUrl = urlparse(url)
    queryParams = parsedUrl.query
    newQueryParams = urlencode(params)

    if queryParams:
        newQueryParams = f"{queryParams}&{newQueryParams}"

    return urlunparse(parsedUrl._replace(query=newQueryParams))


def concatAPIAndData(api: str, data: t.Optional[dict] = None):
    if not api.startswith("/"):
        api = "/" + api

    baseAPI = f"url={api}"
    if data is not None:
        dataJSON = json.dumps(data, separators=(",", ":"), ensure_ascii=False)
        baseAPI += dataJSON
    return baseAPI


def joinBaseUrlAPI(baseUrl: str, apiRoute: str):
    if not baseUrl.endswith("/"):
        baseUrl += "/"

    if apiRoute.startswith("/"):
        apiRoute = apiRoute[1:]

    return baseUrl + apiRoute


def generateRandomString(count: int) -> str:
    characters = "abcdefghijklmnopqrstuvwxyz1234567890"
    return "".join(random.choice(characters) for _ in range(count))


def generateTraceId():
    nowTime = int(datetime.now().timestamp() * 1000)

    # 处理时间部分
    timePart = nowTime & 0xFFFFFFFFFFFFF  # 取低49位
    shifted = (timePart << 23) & 0xFFFFFFFFFFFFFFFF  # 左移23位，保留64位
    seqNum = Int.seq()
    combined = shifted | seqNum
    hexPart1 = format(combined, "016x")  # 转换为16位十六进制，小写

    # 处理随机部分
    randomPart = (Int.random(32) << 32) | Int.random(32)
    hexPart2 = format(randomPart, "016x")

    return f"{hexPart1}{hexPart2}"


def getDataMD5(data: str):
    return hashlib.md5(data.encode()).hexdigest()


def getDataISOCRC32(data: str) -> int:
    crcTable = []
    for a in range(256):
        r = a
        for _ in range(8):
            r = 0xEDB88320 ^ (r >> 1) if r & 1 else r >> 1
        crcTable.append(r)

    crc = -1
    for char in data:
        crc = unsignedRightShift(crc, 8) ^ crcTable[255 & (crc ^ ord(char))]

    return unsignedRightShift(-1 ^ crc, 0)


def getDataXHSCRC32(data: str) -> int:
    def to_signed_32bit(x: int) -> int:
        x &= 0xFFFFFFFF
        return x - 0x100000000 if x >= 0x80000000 else x

    crc = getDataISOCRC32(data)
    return to_signed_32bit(crc ^ 0xEDB88320)


def encodeBase64(data: str):
    return base64.b64encode(data.encode()).decode()


def decodeBase64(encodedData: str):
    return base64.b64decode(encodedData.encode()).decode()


def encryptRC4(plaintext: str, key: str) -> str:
    textBytes = bytes(plaintext, "latin1")
    keyBytes = bytes(key, "latin1")
    cipher = ARC4.new(keyBytes)
    ciphertext = cipher.encrypt(textBytes)
    return ciphertext.decode("latin1")


def decryptRC4(ciphertext: str, key: str) -> str:
    cipherBytes = bytes(ciphertext, "latin1")
    keyBytes = bytes(key, "latin1")
    cipher = ARC4.new(keyBytes)
    textBytes = cipher.decrypt(cipherBytes)
    return textBytes.decode("latin1")


def encodeCustomBase64(inputBytes: bytes):
    trans = bytes.maketrans(
        Default.STANDARD_BASE64_LOOKUP, Default.CUSTOM_BASE64_LOOKUP
    )
    return base64.b64encode(inputBytes).translate(trans).decode()


def decodeCustomBase64(inputString: str):
    trans = bytes.maketrans(
        Default.CUSTOM_BASE64_LOOKUP, Default.STANDARD_BASE64_LOOKUP
    )
    return base64.b64decode(inputString.encode().translate(trans))


def encryptAES(
    plaintext: t.Union[str, bytes], key: t.List[int], iv: t.List[int], tail: int
):
    # 转换key和iv
    ivBytes = bytes(iv)
    keyBytes = b"".join(i.to_bytes(4, "big") for i in key)
    # 1. 将明文转换为Base64
    if isinstance(plaintext, bytes):
        base64Text = base64.b64encode(plaintext)
    elif isinstance(plaintext, str):
        base64Text = base64.b64encode(plaintext.encode())
    else:
        raise TypeError("Types other than str and bytes are not supported.")
    # 2. 将Base64字符串的每个字符转换为ASCII码
    asciiArray = [ord(char) for char in base64Text.decode()]
    # 3. 补充 tail 直到达到208位
    while len(asciiArray) < 208:
        asciiArray.append(tail)
    # 将ASCII列表转换回字节
    plaintext = bytes(asciiArray)
    # 创建AES密码对象
    cipher = AES.new(keyBytes, AES.MODE_CBC, ivBytes)
    # 加密
    ciphertext = cipher.encrypt(plaintext)
    # 将结果转换为十六进制字符串
    return ciphertext.hex()


def decryptAES(ciphertext: str, key: t.List[int], iv: t.List[int], tail: int):
    # 转换key和iv
    ivBytes = bytes(iv)
    keyBytes = b"".join(i.to_bytes(4, "big") for i in key)
    # 将十六进制字符串转换回字节
    textBytes = bytes.fromhex(ciphertext)
    # 创建AES密码对象
    cipher = AES.new(keyBytes, AES.MODE_CBC, ivBytes)
    # 解密
    decrypted = cipher.decrypt(textBytes)
    # 移除填充
    while decrypted[-1] == tail:
        decrypted = decrypted[:-1]
    # 转换回Base64
    base64Text = decrypted.decode()
    # 解码Base64
    plaintext = base64.b64decode(base64Text)
    return plaintext
