import typing as t
import time
from .obj import XObject, XResult

SORT_TYPE: t.Dict[t.Literal["综合", "最新", "最热"], str] = {
    "综合": "general",
    "最新": "time_descending",
    "最热": "popularity_descending",
}
NOTE_TYPE: t.Dict[t.Literal["全部", "视频", "图文"], int] = {
    "全部": 0,
    "视频": 1,
    "图文": 2,
}
MESSAGE_TYPE: t.Dict[t.Literal["评论和艾特", "新增关注", "新增点赞"], str] = {
    "评论和艾特": "mentions",
    "新增关注": "connections",
    "新增点赞": "likes",
}


def getHomefeedCategory(
    xo: XObject, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取主页上方一排热门分类目录

    例: getHomefeedCategory(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/sns/web/v1/homefeed/category", headers=headers)


def postHomefeedNotes(
    xo: XObject,
    cursorScore: str = "",
    num: int = 30,
    refreshType: int = 1,
    noteIndex: int = 0,
    needNum: int = 10,
    searchKey: str = "",
    category: str = "homefeed_recommend",
    needFilterImage: bool = False,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取红薯主页推荐的笔记数据

    例: postHomefeedNotes(xo, num=30)

    :param xo: XObject 实例
    :param cursorScore: 光标分数
    :param num: 总条数(采集80, 只能接近80 不一定有80)
    :param refreshType: 刷新类型
    :param noteIndex: 笔记起始序号
    :param needNum: 需要多少条，从推荐采集的总条数中指定多少条出来
    :param searchKey: 未知作用(默认即可)
    :param category: 目录ID(上方导航选项，默认是推荐 - homefeed_recommend, 可通过 homefeed_category API 获取)
    :param needFilterImage: 需要筛选图像，效果未知
    :param headers: 自定义请求头
    """
    payload = {
        "cursor_score": cursorScore,
        "num": num,
        "refresh_type": refreshType,
        "note_index": noteIndex,
        "unread_begin_note_id": "",
        "unread_end_note_id": "",
        "unread_note_count": 0,
        "category": category,
        "search_key": searchKey,
        "need_num": needNum,
        "image_formats": ["jpg", "webp", "avif"],
        "need_filter_image": needFilterImage,
    }
    return xo.post("/api/sns/web/v1/homefeed", payload, headers=headers)


def getSearchRecommend(
    xo: XObject, keyword: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    搜索推荐（网页端搜索时，根据关键词列举的其他联想词列表）

    例: getSearchRecommend(xo, '宝宝')

    :param xo: XObject 实例
    :param keyword: 关键词
    :param headers: 自定义请求头
    """
    params = {"keyword": keyword}
    return xo.get("/api/sns/web/v1/search/recommend", params, headers=headers)


def getSearchFilter(
    xo: XObject, keyword: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取搜索出现的筛选词（网页端全部、图文等下一栏的那些数据），用于 postSearchNotes API 的 filters 参数

    例: getSearchFilter(xo, '大学生')

    :param xo: XObject 实例
    :param keyword: 关键词
    :param headers: 自定义请求头
    """
    params = {"keyword": keyword, "search_id": xo.config.searchId}
    return xo.get("/api/sns/web/v1/search/filters", params, headers=headers)


def getSearchTrend(
    xo: XObject, lastQuery: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    搜索趋势显示（网页端显示：猜你想搜？）
    网页端是根据上一次搜索的关键词发起这个接口的（部分参数我已经省略）

    例: getSearchTrend(xo, '包包')

    :param xo: XObject 实例
    :param lastQuery: 关键词
    :param headers: 自定义请求头
    """
    params = {
        "source": "search",
        "search_type": "trend",
        "last_query": lastQuery,
        "last_query_time": str(int(time.time() * 1000)),
        "word_request_situation": "BACK_WITH_DEL_WORD",
        "hint_word": "",
        "hint_word_type": "",
        "hint_word_request_id": "",
    }
    return xo.get("/api/sns/web/v1/search/querytrending", params, headers=headers)


def postSearchUser(
    xo: XObject,
    keyword: str,
    page: int = 1,
    pageSize: int = 20,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    搜索用户

    例: postSearchUser(xo, '包包', 1, 20)

    :param xo: XObject 实例
    :param keyword: 关键词
    :param page: 页码
    :param pageSize: 数量(推荐20, 其他数值不一定有效)
    :param headers: 自定义请求头
    """
    payload = {
        "search_user_request": {
            "keyword": keyword,
            "search_id": xo.config.searchId,
            "page": int(page),
            "page_size": int(pageSize),
            "biz_type": "web_search_user",
            "request_id": xo.config.requestId,
        }
    }
    return xo.post("/api/sns/web/v1/search/usersearch", payload, headers=headers)


def postSearchNotes(
    xo: XObject,
    keyword: str,
    page: int,
    pageSize: int,
    sortType: str,
    noteType: int,
    filters: t.Optional[str] = None,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    搜索笔记

    例: postSearchNotes(xo, '包包', 1, 20, xhs.SORT_TYPE['最热'], xhs.NOTE_TYPE['图文'])

    :param xo: XObject 实例
    :param keyword: 关键词
    :param page: 页码
    :param pageSize: 数量(推荐20, 其他数值不一定有效)
    :param sortType: 排序类型（推荐使用 SORT_TYPE 字典，最新、最热、综合）
    :param noteType: 笔记类型（推荐使用 NOTE_TYPE 字典，图文、视频、全部）
    :param filters: 筛选关键词, 是json字符串: '[{"type":"filter_hot","tags":["大学生"]}]', 通过 getSearchFilter API 可获取
    :param headers: 自定义请求头
    """
    if sortType not in SORT_TYPE.values():
        raise ValueError(f"The value `{sortType}` is not within SORT_TYPE.")

    if noteType not in NOTE_TYPE.values():
        raise ValueError(f"The value `{noteType}` is not within NOTE_TYPE.")

    payload = {
        "keyword": keyword,
        "page": page,
        "page_size": pageSize,
        "search_id": xo.config.searchId,
        "sort": sortType,
        "note_type": noteType,
        "image_scenes": "FD_PRV_WEBP,FD_WM_WEBP",
    }
    if filters:
        # "[{"type":"filter_hot","tags":["大学生"]}]"
        payload["filters"] = filters

    return xo.post("/api/sns/web/v1/search/notes", payload, headers=headers)


def postSearchOnebox(
    xo: XObject, keyword: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    网页端搜索笔记时触发，作用未知

    例: postSearchOnebox(xo, '包包')

    :param xo: XObject 实例
    :param keyword: 关键词
    :param headers: 自定义请求头
    """
    payload = {
        "keyword": keyword,
        "search_id": xo.config.searchId,
        "biz_type": "web_search_user",
        "request_id": xo.config.requestId,
    }
    return xo.post("/api/sns/web/v1/search/onebox", payload, headers=headers)


def getSearchAtUsers(
    xo: XObject,
    keyword: str,
    page: int = 1,
    num: int = 30,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    搜索可艾特的用户

    例: getSearchAtUsers(xo, '择', 1, 30)

    :param xo: XObject 实例
    :param keyword: 搜索的用户名（可全称或者部分名字）
    :param page: 页码
    :param num: 显示数量
    :param headers: 自定义请求头
    """
    params = {"keyword": keyword, "page": page, "rows": num}
    return xo.get(
        "/api/sns/web/v1/intimacy/intimacy_list/search", params, headers=headers
    )


def postFollowUser(
    xo: XObject, targetUserId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    关注用户

    例: postFollowUser(xo, '659e39250000000022000b2c')

    :param xo: XObject 实例
    :param targetUserId: 待关注用户的 User ID
    :param headers: 自定义请求头
    """
    payload = {"target_user_id": targetUserId}
    return xo.post("/api/sns/web/v1/user/follow", payload, headers=headers)


def postUnfollowUser(
    xo: XObject, targetUserId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    取消关注用户

    例: postUnfollowUser(xo, '659e39250000000022000b2c')

    :param xo: XObject 实例
    :param targetUserId: 待取消关注用户的 User ID
    :param headers: 自定义请求头
    """
    payload = {"target_user_id": targetUserId}
    return xo.post("/api/sns/web/v1/user/unfollow", payload, headers=headers)


def postNoteFeed(
    xo: XObject,
    sourceNoteId: str,
    xsecToken: str,
    xsecSource: str,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取笔记的数据详情

    例: postNoteFeed(xo, "675cd0e3000000000603b42a", "ABWzbsd2MBDd5Osh48wkHcVcZvwc8xeeSRowzPwCPYH6w=", "pc_feed")

    :param xo: XObject 实例
    :param sourceNoteId: 目标笔记的 ID
    :param xsecToken: 目标笔记的 xsec_token
    :param xsecSource: 目标笔记的来源
        - pc_feed: 推荐页来源
        - pc_search: 搜索页来源

    :param headers: 自定义请求头
    """
    payload = {
        "source_note_id": sourceNoteId,
        "xsec_token": xsecToken,
        "xsec_source": xsecSource,
        "image_formats": ["jpg", "webp", "avif"],
        "extra": {"need_body_topic": "1"},
    }
    return xo.post("/api/sns/web/v1/feed", payload, headers=headers)


def postCollectNote(
    xo: XObject, noteId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    收藏笔记

    例: postCollectNote(xo, '659e39250000000022000b2c')

    :param xo: XObject 实例
    :param noteId: 待收藏笔记的 ID
    :param headers: 自定义请求头
    """
    payload = {"note_id": noteId}
    return xo.post("/api/sns/web/v1/note/collect", payload, headers=headers)


def postUncollectNote(
    xo: XObject, noteId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    取消收藏笔记

    例: postUncollectNote(xo, '659e39250000000022000b2c')

    :param xo: XObject 实例
    :param noteId: 待取消收藏笔记的 ID
    :param headers: 自定义请求头
    """
    payload = {"note_ids": noteId}
    return xo.post("/api/sns/web/v1/note/uncollect", payload, headers=headers)


def postLikeNote(
    xo: XObject, noteId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    点赞笔记

    例: postLikeNote(xo, '659e39250000000022000b2c')

    :param xo: XObject 实例
    :param noteId: 待点赞笔记的 ID
    :param headers: 自定义请求头
    """
    payload = {"note_oid": noteId}
    return xo.post("/api/sns/web/v1/note/like", payload, headers=headers)


def postDislikeNote(
    xo: XObject, noteId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    取消点赞笔记

    例: postDislikeNote(xo, '659e39250000000022000b2c')

    :param xo: XObject 实例
    :param noteId: 待取消点赞笔记的 ID
    :param headers: 自定义请求头
    """
    payload = {"note_oid": noteId}
    return xo.post("/api/sns/web/v1/note/dislike", payload, headers=headers)


def postCommentNote(
    xo: XObject,
    noteId: str,
    content: str,
    atUsers: t.Optional[t.List[t.Dict[str, str]]] = None,
    targetCommentId: t.Optional[str] = None,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    提交评论（笔记下评论与评论回复）

    例1: 评论笔记
        postCommentNote(笔记ID, 评论内容)

    例2: 艾特用户
        atUsers = [{"nickname": "小红薯65F82959", "user_id": "65f6a548000000001700d4a8_一串32位值"},]

        # 艾特用户中的 user_id 并不是纯粹的 uid, 而是 uid_xxxx
        # 可调用 getSearchAtUsers API 接口来获取这个 user_id

        postCommentNote(xo, 笔记ID, '好吃！ @小红薯65F82959 ', atUsers)

    例3: 回复评论
        某条评论的 ID 为: 66570299000000001202d51b

        那么可以: postCommentNote(xo, 笔记ID, 评论内容, targetCommentId='66570299000000001202d51b')

    :param xo: XObject 实例
    :param noteId: 待评论笔记的 ID
    :param content: 评论内容
    :param atUsers: 需要艾特的用户列表(参见例2)
    :param targetCommentId: 回复评论的目标评论ID(参见例子)
    :param headers: 自定义请求头
    """
    atUsers = atUsers or []
    payload = {"note_id": noteId, "content": content, "at_users": atUsers}
    if targetCommentId:
        payload["target_comment_id"] = targetCommentId
    return xo.post("/api/sns/web/v1/comment/post", payload, headers=headers)


def postDeleteComment(
    xo: XObject,
    noteId: str,
    commentId: str,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    删除某条笔记下评论（只能删除自己的）

    例: postDeleteComment(xo, 笔记ID, 评论ID)

    :param xo: XObject 实例
    :param noteId: 笔记的 ID
    :param commentId: 待删除评论的 ID
    :param headers: 自定义请求头
    """
    payload = {"note_id": noteId, "comment_id": commentId}
    return xo.post("/api/sns/web/v1/comment/delete", payload, headers)


def postLikeComment(
    xo: XObject,
    noteId: str,
    commentId: str,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    点赞评论

    例: postLikeComment(xo, 笔记ID, 评论ID)

    :param xo: XObject 实例
    :param noteId: 笔记的 ID
    :param commentId: 待点赞评论的 ID
    :param headers: 自定义请求头
    """
    payload = {"note_id": noteId, "comment_id": commentId}
    return xo.post("/api/sns/web/v1/comment/like", payload, headers=headers)


def postDislikeComment(
    xo: XObject,
    noteId: str,
    commentId: str,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    取消点赞评论

    例: postDislikeComment(xo, 笔记ID, 评论ID)

    :param xo: XObject 实例
    :param noteId: 笔记的 ID
    :param commentId: 待取消点赞评论的 ID
    :param headers: 自定义请求头
    """
    payload = {"note_id": noteId, "comment_id": commentId}
    return xo.post("/api/sns/web/v1/comment/dislike", payload, headers=headers)


def postActivateSession(
    xo: XObject, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    激活会话（返回一个 session 值，未登录时则返回游客身份的 session 值）

    如果 xo 对象未设置 autoSetCookie 为 True, 则不能 xo 的 web_session 将无法及时更新，你需要手动管理 cookie

    例: postActivateSession(xp)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.post("/api/sns/web/v1/login/activate", {}, headers=headers)


def getMySimpleInfo(
    xo: XObject, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取个人信息，信息内容简单

    例: getMySimpleInfo(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/sns/web/v2/user/me", headers=headers)


def getMyFullInfo(xo: XObject, headers: t.Optional[t.Dict[str, str]] = None) -> XResult:
    """
    获取个人完整信息

    例: getMyFullInfo(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/sns/web/v1/user/selfinfo", headers=headers)


def getUserInfo(
    xo: XObject, userId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取指定用户的资料信息

    例: getUserInfo(xo, uid)

    :param xo: XObject 实例
    :param userId: 目标用户的 User ID
    :param headers: 自定义请求头
    """
    params = {"target_user_id": userId}
    return xo.get("/api/sns/web/v1/user/otherinfo", params, headers=headers)


def getUserPostedNotes(
    xo: XObject,
    userId: str,
    xsec_token: str,
    xsec_source: str = "pc_feed",
    cursor: str = "",
    num: int = 30,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取指定用户的作品信息（无权限则获取空列表）

    例: getUserPostedNotes(xo, uid, "xsec_token")

    :param xo: XObject 实例
    :param userId: 目标用户的 User ID
    :param xsec_token: xsec_token
    :param xsec_source: xsec_source(默认pc_feed)
    :param cursor: 翻页游标，默认为空字符串
    :param num: 笔记数量(默认30)
    :param headers: 自定义请求头
    """
    params = {
        "num": num,
        "cursor": cursor,
        "user_id": userId,
        "image_scenes": "jpg,webp,avif",
        "xsec_token": xsec_token,
        "xsec_source": xsec_source,
    }
    return xo.get("/api/sns/web/v1/user_posted", params, headers=headers)


def getUserCollectedNotes(
    xo: XObject,
    userId: str,
    xsec_token: str,
    xsec_source: str = "pc_feed",
    cursor: str = "",
    num: int = 30,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取用户的已收藏的作品信息（无权限则获取空列表）

    例: getUserCollectedNotes(xo, uid, "xsec_token")

    :param xo: XObject 实例
    :param userId: 目标用户的 User ID
    :param xsec_token: xsec_token
    :param xsec_source: xsec_source(默认pc_feed)
    :param cursor: 翻页游标，默认为空字符串
    :param num: 笔记数量(默认30)
    :param headers: 自定义请求头
    """
    params = {
        "num": num,
        "cursor": cursor,
        "user_id": userId,
        "image_scenes": "jpg,webp,avif",
        "xsec_token": xsec_token,
        "xsec_source": xsec_source,
    }
    return xo.get("/api/sns/web/v2/note/collect/page", params, headers=headers)


def getUserCollectedBoards(
    xo: XObject,
    userId: str,
    xsec_token: str,
    xsec_source: str = "pc_feed",
    page: int = 1,
    num: int = 30,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取用户的已收藏的专辑信息（无权限则获取空列表）

    例: getUserCollectedBoards(xo, uid, "xsec_token")

    :param xo: XObject 实例
    :param userId: 目标用户的 User ID
    :param xsec_token: xsec_token
    :param xsec_source: xsec_source(默认pc_feed)
    :param page: 翻页页码(默认1)
    :param num: 笔记数量(默认30)
    :param headers: 自定义请求头
    """
    params = {
        "user_id": userId,
        "page": page,
        "num": num,
        "image_scenes": "jpg,webp,avif",
        "xsec_token": xsec_token,
        "xsec_source": xsec_source,
    }
    return xo.get("/api/sns/web/v1/board/user", params, headers=headers)


def getUserLikedNotes(
    xo: XObject,
    userId: str,
    xsec_token: str,
    xsec_source: str = "pc_feed",
    cursor: str = "",
    num: int = 30,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取用户的已点赞的作品信息（无权限则获取空列表）

    例: getUserLikedNotes(xo, uid, 'xsec_token')

    :param xo: XObject 实例
    :param userId: 目标用户的 User ID
    :param xsec_token: xsec_token
    :param xsec_source: xsec_source(默认pc_feed)
    :param cursor: 翻页游标，默认为空字符串
    :param num: 笔记数量(默认30)
    :param headers: 自定义请求头
    """
    params = {
        "num": num,
        "cursor": cursor,
        "user_id": userId,
        "image_scenes": "jpg,webp,avif",
        "xsec_token": xsec_token,
        "xsec_source": xsec_source,
    }
    return xo.get("/api/sns/web/v1/note/like/page", params, headers=headers)


def getNoteComments(
    xo: XObject,
    noteId: str,
    xsecToken: str,
    cursor: str = "",
    topCommentId: str = "",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    查看笔记下的评论(单次最多 10 条)

    例: getNoteComments(xo, 笔记ID, 笔记XsecToken)

    :param xo: XObject 实例
    :param noteId: 笔记的 note ID
    :param xsecToken: 笔记的 xsec-token 值，可通过采集得到，比如推荐页推送的或者搜索笔记时，其中都会有笔记的 xsec-token 值
    :param cursor: 起始光标（可用于获取一条笔记下的所有评论）
    :param topCommentId: 返回数据时需要置顶的评论 ID
    :param headers: 自定义请求头
    """
    params = {
        "note_id": noteId,
        "cursor": cursor,  # 评论列表中最后一个的comment_id，滚动时有用
        "top_comment_id": topCommentId,
        "image_formats": "jpg,webp,avif",
        "xsec_token": xsecToken,
    }
    return xo.get("/api/sns/web/v2/comment/page", params, headers=headers)


def getNoteSubComments(
    xo: XObject,
    noteId: str,
    xsecToken: str,
    rootCommentId: str,
    num: int = 10,
    cursor: str = "",
    topCommentId: str = "",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    查看某评论下的子评论

    例: getNoteSubComments(xo, 笔记ID, 笔记XsecToken, 评论ID, 10)

    :param xo: XObject 实例
    :param noteId: 笔记的 ID
    :param xsecToken: 笔记的 xsec-token 值，可通过采集得到，比如推荐页推送的或者搜索笔记时，其中都会有笔记的 xsec-token 值
    :param rootCommentId: 带查看的评论的 ID
    :param num: 获取子评论的数量(默认10)
    :param cursor: 起始光标（可用于获取一条笔记下的所有评论）
    :param topCommentId: 返回数据时需要置顶的评论 ID
    :param headers: 自定义请求头
    """
    params = {
        "note_id": noteId,
        "root_comment_id": rootCommentId,
        "num": num,
        "cursor": cursor,  # 子评论列表中最后一个的comment_id，滚动时应该有用
        "image_formats": "jpg,webp,avif",
        "top_comment_id": topCommentId,
        "xsec_token": xsecToken,
    }
    return xo.get("/api/sns/web/v2/comment/sub/page", params, headers=headers)


def getIntimacyAtUsers(
    xo: XObject, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取当前用户可艾特的用户

    例: getIntimacyAtUsers(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/sns/web/v1/intimacy/intimacy_list", headers=headers)


def getEmojiVersion(
    xo: XObject, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取表情包的版本信息

    例: getEmojiVersion(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/im/redmoji/version", headers=headers)


def getEmojiInfo(xo: XObject, headers: t.Optional[t.Dict[str, str]] = None) -> XResult:
    """
    获取官方表情包

    例: getEmojiInfo(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/im/redmoji/detail", headers=headers)


def getUserLogout(xo: XObject, headers: t.Optional[t.Dict[str, str]] = None) -> XResult:
    """
    用户注销登录，游客身份注销时 session 仍然有用

    如果 xo 对象设置 autoSetCookie 为 True 时，该接口会将当前 xo 的 web_session 置空

    例: getUserLogout(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/sns/web/v1/login/logout", headers=headers)


def postCreateQrcode(
    xo: XObject, qrType: int = 1, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    创建二维码，返回的字典中应包含有 qr_id 和 code、url 均为字符串，创建二维码前的 cookie 可能需要是游客身份，参见 postActivateSession API

    例: postCreateQrcode(xo)

    可利用 qr_id 和 code 结合 getQrcodeStatus API 实现二维码扫码状态的获取（微信扫码状态无法监听）

    其中响应的 url 为二维码创建所附加的数据（手机扫码跳转的链接）

    :param xo: XObject 实例
    :param qrType: 二维码类型，官网默认 1
    :param headers: 自定义请求头
    """
    payload = {"qr_type": qrType}
    return xo.post("/api/sns/web/v1/login/qrcode/create", payload, headers=headers)


def getQrcodeStatus(
    xo: XObject, qrId: str, code: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取二维码状态，微信扫码无法监听状态

    扫码确认登录后，正常情况下，如果 xo 对象设置 autoSetCookie 为 True 时，该接口会自动更新 xo 的 web_session

    例: getQrcodeStatus(xo, '163811712764584460', '957144')

    可利用 postCreateQrcode API 获取 qr_id 和 code

    扫码确认登录后，不一定有结果，因为未处理旋转验证码的接口，能力不足
    所以不推荐，除非你能解决，能解决也请在 issues 中共享一下

    目前已知的解决方法：更换指纹貌似可行，否则老老实实使用 Cookie

    :param xo: XObject 实例
    :param qrId: 二维码 ID
    :param code: 登录代码
    :param headers: 自定义请求头
    """
    params = {"qr_id": qrId, "code": code}
    return xo.get("/api/sns/web/v1/login/qrcode/status", params, headers=headers)


def getSendMobileCode(
    xo: XObject,
    phone: str,
    zone: str = "86",
    codeType: str = "login",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    发送手机验证码的接口

    例: getSendMobileCode(xo, '手机号码')

    :param xo: XObject 实例
    :param phone: 手机号码
    :param zone: 区域码(默认值: 86)
    :param codeType: 类型(默认值: login)
    :param headers: 自定义请求头
    """
    params = {
        "phone": phone,
        "zone": zone,
        "type": codeType,
    }
    return xo.get("/api/sns/web/v2/login/send_code", params, headers=headers)


def getCheckMobileCode(
    xo: XObject,
    phone: str,
    verifyCode: str,
    zone: str = "86",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    检查短信验证码的有效性，有效的话将返回数据 mobile_token

    例: getCheckMobileCode(xo, '手机号码', '短信验证码')

    可利用 mobile_token 结合 postUseMobileCode API 获得 Auth 认证的 session

    :param xo: XObject 实例
    :param phone: 手机号码
    :param verifyCode: 验证码
    :param zone: 区域码(默认值: 86)
    :param headers: 自定义请求头
    """
    params = {"phone": phone, "zone": zone, "code": verifyCode}
    return xo.get("/api/sns/web/v1/login/check_code", params, headers=headers)


def postUseMobileCode(
    xo: XObject,
    phone: str,
    mobileToken: str,
    zone: str = "86",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    使用手机令牌获取 session

    登录后，正常情况下，如果 xo 对象设置 autoSetCookie 为 True 时，该接口会自动更新 xo 的 web_session

    例：
        xr = getCheckMobileCode(xo, '手机号码', '短信验证码')
        if xr.success and xr.data:
            postUseMobileCode(xo, '手机号码', xr.data['mobile_token'])

    注意：需要快速使用得到的 mobile_token, 否则很快就无效

    旋转验证码是否出现未知，很少使用该方式

    :param xo: XObject 实例
    :param phone: 手机号码
    :param mobileToken: 验证码验证成功后的手机令牌
    :param zone: 区域码(默认值: 86)
    :param headers: 自定义请求头
    """
    payload = {"phone": phone, "mobile_token": mobileToken, "zone": zone}
    return xo.post("/api/sns/web/v2/login/code", payload, headers=headers)


def getUnreadCount(
    xo: XObject, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取未读的评论、艾特等数量，红薯官方每次轮询时间为 30 秒

    例: getUnreadCount(xo)

    :param xo: XObject 实例
    :param headers: 自定义请求头
    """
    return xo.get("/api/sns/web/unread_count", headers=headers)


def getMyNewLikes(
    xo: XObject,
    num: int = 20,
    cursor: str = "",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取新增点赞消息

    例: getMyNewLikes(xo)

    :param xo: XObject 实例
    :param num: 显示数量
    :param cursor: 显示光标，用于翻页查看更多
    :param headers: 自定义请求头
    """
    params = {
        "num": num,
        "cursor": cursor,
    }
    return xo.get("/api/sns/web/v1/you/likes", params, headers=headers)


def getMyNewMentions(
    xo: XObject,
    num: int = 20,
    cursor: str = "",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取评论和艾特消息

    例: getMyNewMentions(xo)

    :param xo: XObject 实例
    :param num: 显示数量
    :param cursor: 显示光标，用于翻页查看更多
    :param headers: 自定义请求头
    """
    params = {
        "num": num,
        "cursor": cursor,
    }
    return xo.get("/api/sns/web/v1/you/mentions", params, headers=headers)


def getMyNewFollows(
    xo: XObject,
    num: int = 20,
    cursor: str = "",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取新增关注的消息

    例: getMyNewFollows(xo)

    :param xo: XObject 实例
    :param num: 显示数量
    :param cursor: 显示光标，用于翻页查看更多
    :param headers: 自定义请求头
    """
    params = {
        "num": num,
        "cursor": cursor,
    }
    return xo.get("/api/sns/web/v1/you/connections", params, headers=headers)


def postReadMessage(
    xo: XObject,
    messageType=MESSAGE_TYPE["新增关注"],
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    读取指定类型的消息（消除红点点，不可逆）

    例: postReadMessage(xo)

    将消除新增关注的红点点（状态改为已读）

    :param xo: XObject 实例
    :param messageType: 消息类型(mentions/likes/connections)
        - menthions: 评论和艾特
        - likes: 新增点赞
        - connections: 新增关注

    :param headers: 自定义请求头
    """
    payload = {"type": messageType}  # mentions/likes/connections
    return xo.post("/api/sns/web/v1/message/read", payload, headers=headers)


def postReportList(
    xo: XObject,
    targetId: str = "",
    sceneCode: str = "comment",
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    获取举报的条目类型

    例: postReportList(xo)

    :param xo: XObject 实例
    :param targetId: 目标 ID(比如评论 ID、笔记 ID)
    :param sceneCode: 场景代码，目前已知 comment、note
    :param headers: 自定义请求头
    """
    payload = {"target_id": targetId, "scene_code": sceneCode}
    return xo.post("/api/sns/web/report/list", payload, headers=headers)


def postReportSubmit(
    xo: XObject,
    targetId: str,
    targetUserId: str,
    reportItem: t.Dict[str, str],
    targetType: str = "COMMENT",
    scenarioId: str = "comment_web",
    noteForm: t.Optional[t.Dict] = None,
    headers: t.Optional[t.Dict[str, str]] = None,
) -> XResult:
    """
    提交举报

    例: 举报评论
        postReportSubmit(
        xo,
        '某位用户发出的评论 ID',
        '该用户的 UID',
        {"id":"comment_unfriendly","reason":"不友善、引战"}
        )

    该例子就是举报某个用户的评论`不友善、引战`，具体举报条目需要使用 postReportList API

    :param xo: XObject 实例
    :param targetId: 目标 ID(比如评论 ID、笔记 ID)
    :param targetUserId: 目标用户的 UID
    :param reportItem: 举报条目，需要通过 report_list 获取, 位于response['data']['item']之中，格式：{"id":"<type_code>","reason":"type_name"}
    :param targetType: 目标类型，目前已知: COMMENT/NOTE
    :param scenarioId: 场景 ID, 目前已知: comment_web/note_web
    :param noteForm: 举报类型为笔记时，需要提交的额外信息，以字典类型填入（具体参考官网举报请求）
    :param headers: 自定义请求头
    """
    payload = {
        "target_type": targetType,
        "target_id": targetId,
        "scenario_id": scenarioId,
        "report_item": reportItem,
        "target_user_id": targetUserId,
    }
    if targetType.upper() == "NOTE":
        payload.update(noteForm or {})

    return xo.post("/api/sns/web/report/submit", payload, headers=headers)


def getUserHoverCard(
    xo: XObject, userId: str, headers: t.Optional[t.Dict[str, str]] = None
) -> XResult:
    """
    获取用户悬浮简要信息面板，该信息中无性别，需要做性别筛选的请放弃

    评论区用鼠标悬浮在用户头像上出现的小面板

    例: getUserHoverCard(xo, uid)

    :param xo: XObject 实例
    :param userId: 用户的 ID
    :param headers: 自定义请求头
    """
    params = {
        "target_user_id": userId,
        "image_formats": ["jpg", "webp", "avif"],
    }
    return xo.get("/api/sns/web/v1/user/hover_card", params, headers=headers)


def testAPI():
    """主要用于测试加密是否生效"""
    cookie = "abRequestId=e6355a02-6c14-508d-9a08-3039f8c5b211; xsecappid=xhs-pc-web; a1=19146070328qzj6xxb3qac9mhnhu3rltv7m87pm6s50000373241; webId=11a0771982e2e50f874bbe9d0575ae99; gid=yjy4K8W8K8h8yjy4K8W8qWU6JYAuVKCCDqA06KMSj6xIxY287qF19W888qWqJ4y8Y4D0yYSq; webBuild=4.54.0; acw_tc=0a5087ff17366851246326066e8d947dac60bf9306096bd160c79f2c0bf2a4; websectiga=3fff3a6f9f07284b62c0f2ebf91a3b10193175c06e4f71492b60e056edcdebb2; sec_poison_id=7b646b8d-ef13-4ae8-8962-f78aa3864b48"
    xo = XObject(cookie=cookie)
    xo.generateUserAgent(browser="edge", system="windows")
    postActivateSession(xo)
    getHomefeedCategory(xo).debug()
